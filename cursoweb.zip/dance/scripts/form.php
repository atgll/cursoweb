<?php
echo "<pre>";
var_export($_REQUEST);
echo "</pre>";
