<?php
    // print_r($_POST);
    echo "<pre>";
    var_export($_REQUEST);
    echo "</pre>";
?>